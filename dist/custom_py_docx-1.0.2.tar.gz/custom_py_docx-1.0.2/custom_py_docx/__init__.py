"""
.. include:: ../README.srt
.. include:: ../CHANGELOG.md
"""

__version__ = '1.0.2'